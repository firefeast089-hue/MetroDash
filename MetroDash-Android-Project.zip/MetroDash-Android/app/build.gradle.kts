plugins {
    id("com.android.application")
}

android {
    namespace = "com.kbsyt.metrodash"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.kbsyt.metrodash"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
